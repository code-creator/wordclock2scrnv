v 0.9.0.1
Data from Wc24h1816_16-05,5.Feb.2015, CodeGen v0.15 mit Korrektur Countdown 20 Min vor Mitternacht

Der Screensaver kann im normalen Modus oder im Simulatormodus betrieben werden.
Dazu in der Konfiguration das entsprechende H�kchen setzen (Simulation mode).

Im Simulatormodus kann man mit den Cursortasten links/rechts die Zeit minutenweise �ndern,
mit den Cursortasten hoch/runter �ndert man nur die Stunde.

Mit Leertaste und 'm'-Taste wird der DisplayModus vor/zur�ck durchgeschaltet.

Im Simulatormodus wird unten auch der aktuelle DisplayModus und 
die angezeigte Uhrzeit als Text ausgegeben (das kann ja ver�ndert werden).

Wenn die Zeit im Simulatormodus einmal ge�ndert wurde, erfolgt keine Aktualisierung
der Zeitausgabe bis der Screensaver beendet wird.

